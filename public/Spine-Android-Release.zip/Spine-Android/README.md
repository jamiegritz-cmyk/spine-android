# SPINE - Native Android CD Music Player for Pixel 9

100% Native Android Project written with Kotlin, Jetpack Compose, Media3 (ExoPlayer), Room, and MediaStore.

## How to Install and Run on Google Pixel 9:

### Option A: Via Android Studio (Recommended)
1. Unzip this file onto your computer.
2. Open Android Studio (Ladybug, Koala, or newer).
3. Select **File > Open** and choose the unzipped `Spine-Android` folder.
4. Let Gradle sync dependencies automatically.
5. Connect your Pixel 9 via USB (with **Developer Options > USB Debugging** enabled) or via Wi-Fi debugging.
6. Click the green **Run (▶)** button in Android Studio.
7. The app will compile, install directly onto your Pixel 9, and launch the native SPINE music player!

### Option B: Build APK with Command Line
```bash
cd Spine-Android
./gradlew assembleDebug
```
The compiled APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

Install onto your Pixel 9 using ADB:
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
