package com.spine.musicplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.spine.musicplayer.ui.PlayerScreen
import com.spine.musicplayer.ui.theme.SpineTheme
import com.spine.musicplayer.viewmodel.PlayerViewModel

class MainActivity : ComponentActivity() {

    private val playerViewModel: PlayerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            SpineTheme {
                val uiState by playerViewModel.uiState.collectAsState()

                val audioPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    Manifest.permission.READ_MEDIA_AUDIO
                } else {
                    Manifest.permission.READ_EXTERNAL_STORAGE
                }

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    if (isGranted) {
                        playerViewModel.loadLocalMusic()
                    }
                }

                LaunchedEffect(Unit) {
                    val isGranted = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        audioPermission
                    ) == PackageManager.PERMISSION_GRANTED

                    if (isGranted) {
                        playerViewModel.loadLocalMusic()
                    } else {
                        try {
                            permissionLauncher.launch(audioPermission)
                        } catch (_: Exception) {
                            // Non-fatal if permission dialog cannot be triggered immediately
                        }
                    }
                }

                PlayerScreen(
                    uiState = uiState,
                    onSelectRelease = playerViewModel::selectRelease,
                    onPlayPause = playerViewModel::togglePlayPause,
                    onNext = playerViewModel::nextTrack,
                    onPrevious = playerViewModel::previousTrack,
                    onSeek = playerViewModel::seekTo,
                    onToggleShuffle = playerViewModel::toggleShuffle,
                    onCycleRepeat = playerViewModel::cycleRepeatMode,
                    onRefresh = playerViewModel::refreshLibrary,
                    onFilterChange = playerViewModel::setFilterMode,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
